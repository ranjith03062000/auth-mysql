
<div class="data-scrollbar" data-scroll="1">
              <nav class="iq-sidebar-menu">
				
                  <ul id="iq-sidebar-toggle" class="iq-menu">
					  <li class=" ">
                          <a href="{{ url('/users') }}" class="svg-icon">
                              <i class="fa fa-vcard" aria-hidden="true" style="font-size:19px;"> </i>
                              <span class="demo1" style="margin-left:5px;">User</span>
                              
                          </a>
                      </li>
					  
					 
                  </ul>
              </nav>
              
              <div class="p-3"></div>
          </div>
		  <style>
		  
   a:hover span {
    color: #FF7E41;
}
.sidebar-default .iq-sidebar-menu .iq-menu li a:hover  i {
    color: #FF7E41;
}
		  </style>